-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ald
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ead_ald_sections_3_to_9_table`
--

DROP TABLE IF EXISTS `ead_ald_sections_3_to_9_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ead_ald_sections_3_to_9_table` (
  `Submission Number` char(9) DEFAULT NULL,
  `row_id` int NOT NULL AUTO_INCREMENT,
  `Section number` varchar(12) DEFAULT NULL,
  `Section name` varchar(64) DEFAULT NULL,
  `Description` text,
  `PMRA Number` int DEFAULT NULL,
  `Potential Flag` text,
  PRIMARY KEY (`row_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ead_ald_sections_3_to_9_table`
--

LOCK TABLES `ead_ald_sections_3_to_9_table` WRITE;
/*!40000 ALTER TABLE `ead_ald_sections_3_to_9_table` DISABLE KEYS */;
INSERT INTO `ead_ald_sections_3_to_9_table` VALUES ('',1,'1','as','sassd',12,'1'),('',2,'1','asas','dsd',12,'1'),('',3,'2','as','sd',12,'1'),('7',5,'','','sdsf',12,'wq'),('7',6,'','','asas',12,'as'),('7',23,'3','Environmental Risk Drivers','desc',1,'1'),('7',24,'4','Label Considerations and Missing Data','desc',4,'5'),('7',25,'5','Environmental Fate','desc',57,'1'),('7',26,'6','Water Modelling and Monitoring','desc',14,'2'),('7',27,'7','Ecotoxicology','desc',31,'1'),('7',28,'8','Risk Assessment','desc',1,'1'),('7',29,'9','Risk Characterization and Mitigation','desc',56,'1');
/*!40000 ALTER TABLE `ead_ald_sections_3_to_9_table` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-03-26 16:41:27
